
var monkey , monkey_running
var banana ,bananaImage, obstacle, obstacleImage
var foodGroup, obstacleGroup
var score=0;
var ground;
var survivalTime=0;

function preload(){
  
  
  monkey_running =            loadAnimation("sprite_0.png","sprite_1.png","sprite_2.png","sprite_3.png","sprite_4.png","sprite_5.png","sprite_6.png","sprite_7.png","sprite_8.png")
  
  bananaImage = loadImage("banana.png");
  obstacleImage = loadImage("obstacle.png");
 
}



function setup() {
createCanvas(400,400);
  
monkey=createSprite(50,350);
monkey.addAnimation("monkey",monkey_running);
monkey.scale=0.1;
  
ground=createSprite(200,390,400,20);
ground.velocityX=-3;

foodGroup=new Group();
 obstacleGroup=new Group();
  
}


function draw() {
background("white");
  
stroke("black");
textSize(20);
fill("black")
text("Score"+score,500,50);
  
stroke("black");
textSize(20);
fill("black")
survivalTime=Math.round(frameCount/frameRate());
text("Survival Time "+survivalTime,100,50);

  
  

  if (ground.x < 200){
      ground.x = ground.width/2;
    }
  
if(keyDown("space")) {
      monkey.velocityY = -12;
    }
  
    monkey.velocityY = monkey.velocityY + 0.8
  
createFood();
 
createObstacle();
monkey.collide(ground);
drawSprites();
  
}

function createFood(){
if(frameCount % 150 === 0) {
     banana = createSprite(400,200);
    //obstacle.deebug = true;
    banana.velocityX = -4;
    
    //generate random obstacles
    banana.y = Math.round(random(180,300));
   banana.addImage(bananaImage);
    //assign scale and lifetime to the obstacle           
    banana.scale = 0.1  ;
    banana.lifetime = 300;
    //add each obstacle to the group
    foodGroup.add(banana);
  }

}
function createObstacle(){
if(frameCount % 200 === 0) {
      obstacle = createSprite(400,360);
    //obstacle.deebug = true;
    obstacle.velocityX = -4;
    
    //generate random obstacles
    
    obstacle.addImage( obstacleImage);
    //assign scale and lifetime to the obstacle           
     obstacle.scale = 0.1  ;
     obstacle.lifetime = 300;
    //add each obstacle to the group
     obstacleGroup.add( obstacle);
  }

}



